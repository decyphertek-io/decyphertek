
Decyphertek.io
===============================================

Open source technologies can be time consuming and difficult to research and setup. 
We do the research and boil down the notes , so that its easy to understand and use. 
These notes can be used for Enterprise, educational purposes, or DIY projects. 
[decyphertek.io](https://www.decyphertek.io/ 'decyphertek.io')

![Decyphertek](https://github.com/decyphertek-io/configs/raw/main/Logos/decyphertek-logo.png){ align=center }





